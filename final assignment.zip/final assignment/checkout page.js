
var div_tag=document.createElement('div')
div_tag.className='box'


var check_div=document.createElement('div')
check_div.className='check_div'
div_tag.appendChild(check_div)



var check=document.createElement('p')
check.className='check'
check.innerHTML='Checkout'
check_div.appendChild(check)

var items=document.createElement('p')
items.className='items'
items.innerHTML='Total Items: 4'
check_div.appendChild(items)

var left_div=document.createElement('div')
left_div.className='left_div'
check_div.appendChild(left_div)

var items=document.createElement('p')
items.className='items1'
items.innerHTML='Total Items:'
left_div.appendChild(items)

var amount=document.createElement('p')
amount.className='amount1'
amount.innerHTML='Amount: Rs  ' + '<b>'+"27596"+'<b>'
left_div.appendChild(amount)

var place =document.createElement('button')
place.className='place'
place.innerHTML='<a href="http://127.0.0.1:5500/order.html">'+'Place Order'+'</a>'
left_div.appendChild(place)



var img_div=document.createElement('div')
img_div.className='img_div'
check_div.appendChild(img_div)

var img_div1 =document.createElement('div')
img_div1.className='img_div1'
img_div.appendChild(img_div1)

var img1=document.createElement('img')
img1.className='img1'
img1.src="https://assets.myntassets.com/h_1440,q_100,w_1080/v1/assets/images/7579188/2018/11/5/08a7b230-ee8f-46c0-a945-4e835a3c01c01541402833619-United-Colors-of-Benetton-Men-Sweatshirts-1271541402833444-1.jpg"
img_div1.appendChild(img1)

var right=document.createElement('div')
right.className='right'
img_div1.appendChild(right)

var des=document.createElement('p')
des.className='des'
des.innerHTML='Men Navy Blue Solid Sweatshirt'
right.appendChild(des)

var mul=document.createElement('p')
mul.className='mul'
mul.innerHTML='x1'
right.appendChild(mul)

var amount=document.createElement('p')
amount.className='amount'
amount.innerHTML='Amount: Rs 2599'
right.appendChild(amount)











var img_div2 =document.createElement('div')
img_div2.className='img_div2'
img_div.appendChild(img_div2)

var img1=document.createElement('img')
img1.className='img1'
img1.src="https://assets.myntassets.com/h_1440,q_100,w_1080/v1/assets/images/2060340/2017/9/14/11505387708574-Puma-Men-Black-Solid-Sporty-Jacket-371505387708496-1.jpg"
img_div2.appendChild(img1)

var right=document.createElement('div')
right.className='right'
img_div2.appendChild(right)

var des=document.createElement('p')
des.className='des'
des.innerHTML='Men Black MAMGP T7 Sweat Sporty Jacket'
right.appendChild(des)

var mul=document.createElement('p')
mul.className='mul'
mul.innerHTML='x1'
right.appendChild(mul)

var amount=document.createElement('p')
amount.className='amount'
amount.innerHTML='Amount: Rs 7999'
right.appendChild(amount)






var img_div3 =document.createElement('div')
img_div3.className='img_div3'
img_div.appendChild(img_div3)

var img1=document.createElement('img')
img1.className='img1'
img1.src="https://assets.myntassets.com/h_1440,q_100,w_1080/v1/assets/images/productimage/2018/9/19/b1373b00-37d4-41a0-a908-5d742a68d3661537343756229-1.jpg"
img_div3.appendChild(img1)

var right=document.createElement('div')
right.className='right'
img_div3.appendChild(right)

var des=document.createElement('p')
des.className='des'
des.innerHTML='Men Black Action Parkview Lifestyle Shoes'
right.appendChild(des)

var mul=document.createElement('p')
mul.className='mul'
mul.innerHTML='x1'
right.appendChild(mul)

var amount=document.createElement('p')
amount.className='amount'
amount.innerHTML='Amount: Rs 6999'
right.appendChild(amount)







var img_div4 =document.createElement('div')
img_div4.className='img_div4'
img_div.appendChild(img_div4)

var img1=document.createElement('img')
img1.className='img1'
img1.src="https://assets.myntassets.com/h_1440,q_100,w_1080/v1/assets/images/3854721/2018/3/12/11520844673915-BARESKIN-Women-Black-Solid-Lightweight-Leather-Jacket-7761520844673718-1.jpg"
img_div4.appendChild(img1)

var right=document.createElement('div')
right.className='right'
img_div4.appendChild(right)

var des=document.createElement('p')
des.className='des'
des.innerHTML='Women Black Solid Lightweight Leather Jacket'
right.appendChild(des)

var mul=document.createElement('p')
mul.className='mul'
mul.innerHTML='x1'
right.appendChild(mul)

var amount=document.createElement('p')
amount.className='amount'
amount.innerHTML='Amount: Rs 9999'
right.appendChild(amount)


function fun(){
    if(typeof(Storage)!=="undefined"){
      if(localStorage.clickcount){
        localStorage.clickcount=Number(localStorage.clickcount)+1
      }
      else{
        localStorage.clickcount=1
      }
      document.getElementById('count').innerHTML =localStorage.clickcount
    }
    else{
      document.getElementById('count').innerHTML+="not"
    }
  }
  fun()



document.getElementById('section').appendChild(div_tag)


