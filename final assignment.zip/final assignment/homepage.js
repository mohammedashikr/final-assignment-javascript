// alert("hi")

function readpost(){
    var a= new XMLHttpRequest();
    a.open("GET","https://5d76bf96515d1a0014085cf9.mockapi.io/product",true);
    a.send();
    a.onreadystatechange=function(){
        // console.log(this.readyState)
        // console.log(this.status)
        if(this.status==200 && this.readyState==4){
            // console.log(this.responseText)
            // console.log(typeof(this.responseText))
            var main_data =JSON.parse(this.responseText);
            console.log(main_data)
            console.log(typeof(main_data))

            var head_tag = document.createElement("h1");
            head_tag.className = "head";
            head_tag.innerHTML = "Clothing for Men and Women";
            section.appendChild(head_tag);

            var div_tag=document.createElement('div')
            div_tag.className='box'
            // console.log(div_tag)
            for(var x=0;x<main_data.length;x++){
                console.log(main_data[x])
                if(main_data[x].isAccessory==false){
                  var container_tag=document.createElement('div')
                  container_tag.className='containerbox';
                  // console.log(productList[x])
                  div_tag.appendChild(container_tag);
                  //upcard
                  var up_card=document.createElement('a');
                  up_card.href="http://127.0.0.1:5500/product%20page.html";
                  up_card.className="up";
                  container_tag.appendChild(up_card);
                  //img card
                  var img_tag = document.createElement('div');
                  img_tag.className = "img_box";
                  up_card.appendChild(img_tag);
                  var img=document.createElement('img');
                  img.className="image";
                  img.src= main_data[x].preview;
                  img_tag.appendChild(img);
                  //down card
                  var down_card=document.createElement('div');
                  down_card.className="down";
                  //name
                  var name_tag=document.createElement('p');
                  name_tag.className="name";
                  name_tag.innerHTML=main_data[x].name;
                  down_card.appendChild(name_tag);
                  //brand
                  var brand_tag=document.createElement('p');
                  brand_tag.className="brand";
                  brand_tag.innerHTML=main_data[x].brand;
                  down_card.appendChild(brand_tag);
                  //pricex  
                  var price_tag=document.createElement('p');
                  price_tag.className="price";
                  price_tag.innerHTML="Rs "+ main_data[x].price;
                  down_card.appendChild(price_tag);
                  up_card.appendChild(down_card);
                  
                
                }
                 
              }

            document.getElementById("section").appendChild(div_tag);



            var head_tag2 = document.createElement("h1");
            head_tag2.className = "head2";
            head_tag2.innerHTML = "Accessories for Men and Women";
            section.appendChild(head_tag2);
  
  
                //div 2------------------
                var div_tag2=document.createElement('div')
                div_tag2.className='box'
                for(var x=0;x<main_data.length;x++){
                    if(main_data[x].isAccessory==true){
                    var container_tag2=document.createElement('div')
                    container_tag2.className='containerbox';
                    // console.log(productList[x])
                    div_tag2.appendChild(container_tag2);
                    //up card2
                    var up_card2=document.createElement('a');
                    up_card2.href="#";
                    up_card2.className="up";
                    container_tag2.appendChild(up_card2);
                    //img card2
                    var img_tag2 = document.createElement('div');
                    img_tag2.className = "img_box";
                    up_card2.appendChild(img_tag2);
                    var img2=document.createElement('img');
                    img2.className="image";
                    img2.src= main_data[x].preview;
                    img_tag2.appendChild(img2);
                    //down card2
                    var down_card2=document.createElement('div');
                    down_card2.className="down";
                    //name2
                    var name_tag2=document.createElement('p');
                    name_tag2.className="name";
                    name_tag2.innerHTML=main_data[x].name;
                    down_card2.appendChild(name_tag2);
                    //brand2
                    var brand_tag2=document.createElement('p');
                    brand_tag2.className="brand";
                    brand_tag2.innerHTML=main_data[x].brand;
                    down_card2.appendChild(brand_tag2);
                    //price2
                    var price_tag2=document.createElement('p');
                    price_tag2.className="price";
                    price_tag2.innerHTML="Rs "+ main_data[x].price;
                    down_card2.appendChild(price_tag2);
                    up_card2.appendChild(down_card2);
                    
                    
                    }
                    
                }
                document.getElementById("section").appendChild(div_tag2);


        }
    }
}
readpost()
