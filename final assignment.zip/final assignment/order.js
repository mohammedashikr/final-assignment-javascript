// alert("hi")
function readpost(){
    var a= new XMLHttpRequest();
    a.open("GET","https://5d76bf96515d1a0014085cf9.mockapi.io/order",true);
    a.send();
    a.onreadystatechange=function(){
        // console.log(this.readyState)
        // console.log(this.status)
        if(this.status==200 && this.readyState==4){
            // console.log(this.responseText)
            // console.log(typeof(this.responseText))
            var main_data =JSON.parse(this.responseText);
            // console.log(main_data)
            // console.log(typeof(main_data))

            var div_tag=document.createElement('div')
            div_tag.className='box'

            var icon=document.createElement('img')
            icon.className='icon'
            icon.src="https://cdn-icons-png.flaticon.com/512/8212/8212602.png"
            div_tag.appendChild(icon)

            var order=document.createElement('h4')
            order.className='order'
            order.innerHTML="Order Placed Successfully!!"
            div_tag.appendChild(order)


            var order=document.createElement('p')
            order.className='order1'
            order.innerHTML="We have sent you an email with the order details"
            div_tag.appendChild(order)


            


            document.getElementById('section').appendChild(div_tag)

        }
    }
}
readpost()