var productData = {
    "id": "1",
    "name": "Men Navy Blue Solid Sweatshirt",
    "preview": "https://assets.myntassets.com/h_1440,q_100,w_1080/v1/assets/images/7579188/2018/11/5/08a7b230-ee8f-46c0-a945-4e835a3c01c01541402833619-United-Colors-of-Benetton-Men-Sweatshirts-1271541402833444-1.jpg",
    "photos": [
      "https://assets.myntassets.com/h_1440,q_100,w_1080/v1/assets/images/7579188/2018/11/5/08a7b230-ee8f-46c0-a945-4e835a3c01c01541402833619-United-Colors-of-Benetton-Men-Sweatshirts-1271541402833444-1.jpg",
      "https://assets.myntassets.com/h_1440,q_100,w_1080/v1/assets/images/7579188/2018/11/5/efc3d5b9-1bb3-4427-af53-7acae7af98951541402833591-United-Colors-of-Benetton-Men-Sweatshirts-1271541402833444-2.jpg",
      "https://assets.myntassets.com/h_1440,q_100,w_1080/v1/assets/images/7579188/2018/11/5/c7e58861-3431-4189-9903-9880f5eebd181541402833566-United-Colors-of-Benetton-Men-Sweatshirts-1271541402833444-3.jpg",
      "https://assets.myntassets.com/h_1440,q_100,w_1080/v1/assets/images/7579188/2018/11/5/66490b64-32de-44b4-a6e4-fe36f1c040051541402833548-United-Colors-of-Benetton-Men-Sweatshirts-1271541402833444-4.jpg",
      "https://assets.myntassets.com/h_1440,q_100,w_1080/v1/assets/images/7579188/2018/11/5/957be784-7c5d-4e90-ab9f-0928015b22891541402833645-United-Colors-of-Benetton-Men-Sweatshirts-1271541402833444-5.jpg"
    ],
    "description": "Navy solid sweatshirt with patchwork, has a round neck, long sleeves, straight hem",
    "size": [
      1,
      1,
      0,
      1,
      0
    ],
    "isAccessory": false,
    "brand": "United Colors of Benetton",
    "price": 2599
  }


  

  var div_tag=document.createElement('div')
  div_tag.className='main_box'
  
        
        var img_div=document.createElement('div')
        img_div.className='img_div';
        div_tag.appendChild(img_div)

        var img =document.createElement('img')
        img.className='img'
        img.src=productData.preview;
        img_div.appendChild(img)
        
        var container_div=document.createElement('div')
        container_div.className='container_box';
        div_tag.appendChild(container_div)

        var top_div=document.createElement('div')
        top_div.className='top'
        container_div.appendChild(top_div)

        var name_tag=document.createElement('p')
        name_tag.className='name'
        name_tag.innerHTML=productData.name;
        top_div.appendChild(name_tag)

        var brand_tag=document.createElement('p')
        brand_tag.className='brand'
        brand_tag.innerHTML=productData.brand;
        top_div.appendChild(brand_tag)


        var price_tag=document.createElement('p')
        price_tag.className='price'
        price_tag.innerHTML="<span>Price : Rs </span>"+productData.price;
        top_div.appendChild(price_tag)

        var des=document.createElement('p')
        des.className='des'
        des.innerHTML="Description"
        top_div.appendChild(des)

        var des_tag=document.createElement('p')
        des_tag.className='des_tag'
        des_tag.innerHTML=productData.description
        top_div.appendChild(des_tag)

        var pro=document.createElement('p')
        pro.className='pro'
        pro.innerHTML="Product Preview"
        top_div.appendChild(pro)


        // var cart =document.createElement('button')
        // cart.className='cart'
        // cart.innerHTML='Add to cart'
        // top_div.appendChild(cart)

        function fun(){
          if(typeof(Storage)!=="undefined"){
            if(localStorage.clickcount){
              localStorage.clickcount=Number(localStorage.clickcount)+1
            }
            else{
              localStorage.clickcount=1
            }
            document.getElementById('count').innerHTML =localStorage.clickcount
          }
          else{
            document.getElementById('count').innerHTML+="not"
          }
        }
        fun()

        // function clear(){
        //   window.localStorage.clear();
        // }
        // clear()


        


    
       
        var x=document.getElementById('demo') 
        x.addEventListener('click',function(){
          img.src=productData.photos[0];
          demo.style.border="1px solid #009688";
          demo.style.borderRadius = "3px"; 
        })
        var x=document.getElementById('demo1')
        x.addEventListener('click',function(){
          img.src=productData.photos[1];
          demo1.style.border="1px solid #009688";
          demo1.style.borderRadius = "3px"; 
        })
        var x=document.getElementById('demo2')
        x.addEventListener('click',function(){
          img.src=productData.photos[2];
          demo2.style.border="1px solid #009688";
          demo2.style.borderRadius = "3px"; 
         
        })
        var x=document.getElementById('demo3')
        x.addEventListener('click',function(){
          img.src=productData.photos[3];
          demo3.style.border="1px solid #009688";
          demo3.style.borderRadius = "3px"; 
         
        })
        var x=document.getElementById('demo4')
        x.addEventListener('click',function(){
          img.src=productData.photos[4];
          demo4.style.border="1px solid #009688";
          demo4.style.borderRadius = "3px"; 
         
        })
      


  document.getElementById('main').appendChild(div_tag)
  